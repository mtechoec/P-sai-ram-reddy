def binary_insert(exisiting_list,start,end,inserting_list):
    index = (start+end+1)//2
    # print(start, ' --- ', end)

    if(start > end):
        exisiting_list.insert(start, inserting_list)
        return start
    if(exisiting_list[index][0] == inserting_list[0]):
        exisiting_list.insert(index,inserting_list)#future check the 1 index also and return index accordingly
        return index
    if(end == start):
        #append or insert accordingly
        if(exisiting_list[index][0]< inserting_list[0]):#append
            exisiting_list.insert(index+1,inserting_list)
            return index+1
        else:#insert
            exisiting_list.insert(index,inserting_list)
            return index
    if(exisiting_list[index][0] > inserting_list[0]):
        return binary_insert(exisiting_list,start,index-1,inserting_list)
    else:
        return binary_insert(exisiting_list,index+1,end,inserting_list)

def coalescing_link(list_toCoalesc,index):
    del_before = False
    del_after = False
    if(index-1 >= 0):
        if(list_toCoalesc[index-1][1]+1 == list_toCoalesc[index][0]):
            list_toCoalesc[index][0]= list_toCoalesc[index-1][0]
            del_before= True
    if(index+1 < len(list_toCoalesc)):
        if(list_toCoalesc[index+1][0] == list_toCoalesc[index][1]+1):
            list_toCoalesc[index][1] = list_toCoalesc[index+1][1]
            del_after= True

    if(del_before):
        list_toCoalesc.pop(index-1)
        index = index-1#update index as now length gets decreased
    if(del_after):
        list_toCoalesc.pop(index+1)
