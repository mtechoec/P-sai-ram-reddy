from math import log10

gain_to_nf = {
    12: 9.8,13: 9.234,14: 8.723,15: 8.281,16:7.884,17: 7.515,
    18: 7.207,19: 6.923,20: 6.661,21: 6.421,22: 6.199,
    23: 5.995,23.5: 5.89,24: 5.8,
}
gain_to_nf1 = {
    5: 13,
    6: 12.08,
    7: 11.25,
    8: 10.65,
    8.5:10.36,
    9: 10.2,
    10: 9.702,
    11: 9.335,
    12: 9.004,
    13: 8.71,
    13.5:8.56,
    14: 8.417,
    15: 8.181,
    16: 7.965,
    17: 7.768,
    18: 7.586,
    18.5: 7.492,
    19: 7.4,
    20: 7.245,21: 7.1, 22: 6.965,23: 6.838,
    23.5: 6.771,24: 6.719,25: 6.606,26: 6.488,27: 6.387,28: 6.292,28.5: 6.252,
    29: 6.201,30: 6.115,31: 6.032,32: 5.954,33: 5.87,34: 5.8,
}


def dB_to_LI(x):
    return (10 ** (x / 10))


def P_dBm_to_LI(x):
    return (10 ** (x / 10) / (10 ** 3))


# CONSTANTS
h = 6.626e-34
v = 1.9350e14
f = 12.5e9  # @0.1 nm
attenuation = 0.25
connector_loss = 0.5
mul_loss = 6
demul_loss = 6
patch_mess_loss = 2
add_drop_loss = 6
per_channel_power = round(21 - 10 * log10(125)) #21 dBm
print(per_channel_power)


def add_Loss():
    return add_drop_loss + patch_mess_loss + mul_loss


def drop_Loss():
    return add_drop_loss + patch_mess_loss + demul_loss


def convert_path_to_list(path):
    path_list = []
    path_list.append(path[0][0])
    for i in path:
        path_list.append(i[1])
    return path_list


def FindIntermediateOSNR(power_input, OSNR):
    gain = per_channel_power - power_input
    # print("this is gain",gain)
    nf = gain_to_nf[gain]
    # print(nf)
    NF = dB_to_LI(nf)
    P = P_dBm_to_LI(power_input)
    OSNR = 1 / ((1 / OSNR) + (NF * h * v * f) / P)
    return OSNR


def FindIntermediateOSNR1(power_input, OSNR):
    gain = per_channel_power - power_input
    # print("this is gain",gain)
    nf = gain_to_nf1[gain]
    # print(nf)
    NF = dB_to_LI(nf)
    P = P_dBm_to_LI(power_input)
    OSNR = 1 / ((1 / OSNR) + (NF * h * v * f) / P)
    return OSNR


def CalculateOSNR(path, graph):
    path_list = convert_path_to_list(path)
    OSNR = dB_to_LI(100)  # starting OSNR
    power_input = 0
    for i in range(len(path_list)):
        # print(i)
        if i == 0:
            power_input = 0 - add_Loss()
            OSNR = FindIntermediateOSNR(power_input, OSNR)
        else:
            distance = graph[path_list[i - 1] - 1][path_list[i] - 1]  # distance between [i-1],[i]
            # print(distance)
            power_input = per_channel_power - (distance * attenuation + 2 * connector_loss)
            # print("powerinput",power_input,distance * attenuation + 2*connector_loss )
            OSNR = FindIntermediateOSNR1(power_input, OSNR)
            # print(OSNR)
        if (i != len(path_list) - 1 and i != 0):  # dont calculate at zero
            power_input = per_channel_power - (demul_loss + patch_mess_loss + mul_loss + 2 * connector_loss)
            OSNR = FindIntermediateOSNR(power_input, OSNR)
            # print("loss",demul_loss + patch_mess_loss + mul_loss + 2*connector_loss)
            # print(OSNR)
        elif (i != 0):  # for last value
            # print("final OSNR: ", 10 * log10(OSNR), "dB")
            power_at_reciever = per_channel_power - drop_Loss()
            # print("Power at Reciever: ", power_at_reciever)
            return round(10 * log10(OSNR), 3)  # rounding to 3 decimals
            # print("power input", power_input)
            # print("osnr", 10 * log10(OSNR))
            # print(OSNR)

# CalculateOSNR(path)
# TODO overload power
