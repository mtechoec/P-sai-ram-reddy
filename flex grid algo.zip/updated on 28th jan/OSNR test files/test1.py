from math import log10
l= [(1,8),(8,9),(9,10)]

def NF_to_LI(x):
    return(10**(x/10))

def P_to_LI(x):
    return(10**(x/10)/(10**3))

NF = NF_to_LI(5)
h= 6.626e-34
v= 1.9350e14
f= 12.5e9
osnrStage0 = float('inf')
P= P_to_LI(-10.5)
osnrStage= 1/((1/osnrStage0)+(NF*h*v*f)/P)
result = round(10*log10(osnrStage))
print(result,"dB")