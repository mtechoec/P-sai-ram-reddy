from math import log10
l= [(1,8),(8,9),(9,10)]
# a = {1:{NF:}}

gain_to_nf= {
    12:9.6,
    13:8.7,
    14:7.9,
    15:7.2,
    16:6.5,
    17:6.1,
    18:5.8,
    19:5.7,
    20:5.6,
    21:5.5
}

def dB_to_LI(x):
    return(10**(x/10))

def P_to_LI(x):
    return(10**(x/10)/(10**3))

#constants
h= 6.626e-34
v= 1.9350e14
f= 12.5e9
attenuation= 0.2
connector_loss= 1
mul_loss = 6
demul_loss = 6
patch_mess_loss = 2
transponder_loss = 6

def add_Loss():
    return transponder_loss+patch_mess_loss+mul_loss

def drop_Loss():
    return transponder_loss+patch_mess_loss+demul_loss

power0 = 0
first_input_power_of_amplifier= 0-add_Loss()#Pin
#goes to formula as power....

per_channel_power= round(23 - 10*log10(125))#Pout ..fixed

gain= per_channel_power-first_input_power_of_amplifier#Pout -Pin(Db) ..always changes
nf= gain_to_nf[gain]#go to table and get nf

NF = dB_to_LI(nf)
osnrStage0 = 100
#osnrStage0 = dB_to_LI(23.203334181965655)
P= P_to_LI(first_input_power_of_amplifier)
osnrStage1 = 1/((1/osnrStage0)+(NF*h*v*f)/P)#Pin,NF Linear Value
print("NF: ",nf)
print("Power: ",first_input_power_of_amplifier)
print("OSNR: ",10*log10(osnrStage1),"dB")#only for printing ..use for last value
power_output_of_amplifier = first_input_power_of_amplifier+gain
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Stage 2
#2nd node Before Action

fiber_distance_of_first_link= 90

power_in_2nd_amplifier= power_output_of_amplifier-(fiber_distance_of_first_link*attenuation+connector_loss)#previous power_output_amplifier

gain= per_channel_power-power_in_2nd_amplifier
nf= gain_to_nf[gain]

NF = dB_to_LI(nf)
P= P_to_LI(power_in_2nd_amplifier)
osnrStage2 = 1/((1/osnrStage1)+(NF*h*v*f)/P)
outside_power_in_2nd_amplifier= power_in_2nd_amplifier+gain
print("OUTSIDE POWER: ",outside_power_in_2nd_amplifier)
print("NF: ",nf)
print("Power: ",power_in_2nd_amplifier)
print("OSNR: ",10*log10(osnrStage2),"dB")
#Inside 2nd node losses get added

power_booster_2nd_amplifier= outside_power_in_2nd_amplifier - (demul_loss+patch_mess_loss+mul_loss)

#Booster amplifier
gain= per_channel_power-power_booster_2nd_amplifier
nf= gain_to_nf[gain]

NF = dB_to_LI(nf)
P= P_to_LI(power_booster_2nd_amplifier)
osnrStage3 = 1/((1/osnrStage2)+(NF*h*v*f)/P)
outside_power_in_2nd_booster_amplifier= power_booster_2nd_amplifier+gain
print("OUTSIDE POWER: ",outside_power_in_2nd_booster_amplifier)
print("NF: ",nf)
print("Power: ",power_booster_2nd_amplifier)
print("OSNR: ",10*log10(osnrStage3),"dB")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Stage 3
#3nd node Before Action

fiber_distance_of_second_link= 90

power_in_3rd_pre_amplifier= outside_power_in_2nd_booster_amplifier-(fiber_distance_of_second_link*attenuation+connector_loss)#previous power_output_amplifier

gain= per_channel_power-power_in_3rd_pre_amplifier
nf= gain_to_nf[gain]

NF = dB_to_LI(nf)
P= P_to_LI(power_in_3rd_pre_amplifier)
osnrStage4 = 1/((1/osnrStage3)+(NF*h*v*f)/P)
outside_power_in_3rd_pre_amplifier= power_in_3rd_pre_amplifier+gain
print("OUTSIDE POWER: ",outside_power_in_3rd_pre_amplifier)
print("NF: ",nf)
print("Power: ",power_in_3rd_pre_amplifier)
print("OSNR: ",10*log10(osnrStage4),"dB")

#Inside 2nd node losses gtestet added

power_at_reciever = outside_power_in_3rd_pre_amplifier - drop_Loss()
print(power_at_reciever)











##going inside roadam losses
#inside 3rd amplifier

# power_in_3rd_amplifier
