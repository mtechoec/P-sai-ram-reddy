from yen import YenAlgorithm
import sys,tools

class Kpathselection():
    file_name=""
    nodes=[]
    edges=[]
    def __init__(self, s, t):
        self.s = s
        self.t = t

    @staticmethod
    def setFilePath(path):
        Kpathselection.file_name= path
        Kpathselection.nodes,Kpathselection.edges=tools.calculateNodesandEdges(Kpathselection.file_name)
        return len(Kpathselection.nodes)

    def YenKpath(self):
        kpath_list = []
        if(Kpathselection.file_name== ""):
            print("Please use setFile() function before calling this function:")
        self.graph, self.num_nodes, self.num_arcs, id = tools.getGraphStructure(Kpathselection.nodes,Kpathselection.edges)
        while True:
            K = 5  #int(input('Enter the number of paths to search: '))
            if K == 0:
                sys.exit('No path required ... Goodbye!')

            if self.s == self.t or not 1 <= self.s <= self.num_nodes or not 1 <= self.t <= self.num_nodes or K < 0:
                print('WARNING! Recheck the entered values. We remind you that '
                      'the source node and the well node must be different and K> 0'
                      '(K=0 to exit).')
            else:
                break
        shortest_path_tree = YenAlgorithm(self.graph, self.s - 1, self.t - 1,K)  # Decrease the nodes of one because in the data structure the nodes start at 0

        if shortest_path_tree:
            kpaths = tools.printPaths(shortest_path_tree)
            for k in kpaths:
                kpath_list.append(k)
            # print("this is k paths",kpath_list)

            self.dist_path = tools.printDistictPaths(shortest_path_tree)
            # print("this is disjoint paths",self.dist_path)
            for path in self.dist_path:
                pass
                # print("disjoint path \t{}\t distance: {}\t hops: {}".format(path['path'], path['cost'], path['hops']))
        else:
            print('No path between the source and the well node!')
        return kpath_list,self.graph
        # return self.dist_path,self.graph

