import copy, math,ast;import numpy as np
from calculateOSNR import CalculateOSNR
from demand import calculate_slot, printFrequenciesAndCentralFrequency, mod_format, bit_rate_osnr,slot_data_modulation,start_frequency_slice
from intersection import LinkIntersection
from util import binary_insert, coalescing_link
from Kpathselection import Kpathselection
from collections import Counter

cost_all = [];actual_bandwidth=[];demands_not_satisfied=[]
Path_Assignment_Number = 1  # for each network this exits
Demand_Assignment_Number = 1  # for each network this exits
ids_assignment = {}
results_dic = {}
stop_frequency_slice =191.325


def resetPathandDemandId():
    global Path_Assignment_Number, Demand_Assignment_Number, ids_assignment,results_dic,cost_all,actual_bandwidth,demands_not_satisfied
    Path_Assignment_Number = 1
    Demand_Assignment_Number = 1
    ids_assignment = {}
    results_dic = {}
    cost_all = []
    actual_bandwidth = []
    demands_not_satisfied = []


def allocate_to_link(shortest_path, link_matrix_free, link_matrix_allocated, allocate, slots_list, diff,
                     actual_bandwidth, demand, demandceiled,demand_overall_data):
    for j in shortest_path:
        for k in link_matrix_free[j[0] - 1][j[1] - 1]:
            # link_matrix_free[j[0]-1][j[1]-1][0][0]=51
            if (allocate[0] == k[
                0]):  # if both allocating space and existing staring are same then its simple just change the starting element
                k[0] = allocate[1] + 1
                if (k[0] > k[1]):  # then full bandwidth is used
                    link_matrix_free[j[0] - 1][j[1] - 1].remove(k)
            elif (allocate[0] >= k[0] and allocate[1] <= k[
                1]):  # only temporary idea... have to collescing and in sorted order
                link_matrix_free[j[0] - 1][j[1] - 1].remove(k)
                if (k[0] <= allocate[0] - 1):  # =  may be remmoved dont we will see
                    index = binary_insert(link_matrix_free[j[0] - 1][j[1] - 1], 0,
                                          len(link_matrix_free[j[0] - 1][j[1] - 1]) - 1, [k[0], allocate[0] - 1])
                    coalescing_link(link_matrix_free[j[0] - 1][j[1] - 1], index)
                if (allocate[1] + 1 <= k[1]):
                    index = binary_insert(link_matrix_free[j[0] - 1][j[1] - 1], 0,
                                          len(link_matrix_free[j[0] - 1][j[1] - 1]) - 1, [allocate[1] + 1, k[1]])
                    coalescing_link(link_matrix_free[j[0] - 1][j[1] - 1], index)
    fiber_cost=[];transponder_cost=[]
    for i in demand_overall_data:
        fiber_cost.append(i["cost_slots"])
        transponder_cost.append(i["cost_transponders"])


    global Demand_Assignment_Number
    for j in shortest_path:
        v1 = j[0] - 1
        v2 = j[1] - 1
        cost_fiber = (transponder_cost[0]+(fiber_cost[0]*(len(shortest_path))))
        # print(j[0], j[1], link_matrix_allocated[v1][v2])
        link_matrix_allocated[v1][v2].append(
            {'demand': demand,'demand_id': Demand_Assignment_Number, 'slot': allocate,
             'user': 'sai ram', 'path': shortest_path, 'path_id': ids_assignment[str(shortest_path)],
             'slots_list': slots_list, 'diff': diff, 'slots_bandwith': actual_bandwidth,
             'spectral efficeincy': round((demandceiled / actual_bandwidth), 2), 'total_cost': cost_fiber})
    # print(link_matrix_allocated)
    # print(link_matrix_free)




def initialize_matrices(num_nodes):
    slots = math.floor((start_frequency_slice -stop_frequency_slice) / 0.0125)
    # print("slots:", slots)
    link_matrix_free = [[[[1, slots]]] * num_nodes for i in range(num_nodes)]
    link_matrix_allocated = [[[]] * num_nodes for i in range(num_nodes)]
    # making sure all r having different reference
    for j in range(num_nodes):
        for i in range(num_nodes):
            if i <= j:  # upper half triangle refrencing lower half traingle ..therefore there is only have matrix existing in reality
                link_matrix_free[j][i] = copy.deepcopy(
                    link_matrix_free[j][i])  # making deep copy to make sure its not being same everywhere
                link_matrix_free[i][j] = link_matrix_free[j][i]  # making upper triangle refrencing
                link_matrix_allocated[j][i] = link_matrix_allocated[j][i].copy()
                link_matrix_allocated[i][j] = link_matrix_allocated[j][i]  # make refrencing
    return link_matrix_free, link_matrix_allocated


def findFirstFit(intersection_link, slots):
    # in the below we can implement first fit , best fit etc..i prefer first fit :D
    slots = slots - 1  # as index starts from 0
    for j in intersection_link:
        if (j[1] - j[0] >= slots):
            got_demand = True
            return [j[0], slots + j[0]], True
    return [], False


def assign_unique_ids(path):
    global Path_Assignment_Number, ids_assignment
    reverse_path = [(i[1], i[0]) for i in path]
    reverse_path.reverse()
    path_string_combining = str(path)
    path_string_combining_reverse = str(reverse_path)
    if (path_string_combining not in ids_assignment):  # if not exisiting then assign
        if (path_string_combining_reverse not in ids_assignment):
            ids_assignment[path_string_combining] = Path_Assignment_Number
            ids_assignment[path_string_combining_reverse] = Path_Assignment_Number
            Path_Assignment_Number += 1
        else:
            ids_assignment[path_string_combining] = ids_assignment[path_string_combining_reverse]
    else:
        if (path_string_combining_reverse not in ids_assignment):
            ids_assignment[path_string_combining_reverse] = ids_assignment[path_string_combining]


def SortByOsnr(val):
    return val['osnr']


def demand_OSNR(osnr):
    for i in range(0, len(bit_rate_osnr)):
        if osnr > bit_rate_osnr[i]:
            return i

def findAlternativePaths(source, destination):
    kpath1 = Kpathselection(source, destination)
    paths, graph = kpath1.YenKpath()
    for i in paths:
        i['osnr'] = CalculateOSNR(i['path'], graph)
    paths.sort(key=SortByOsnr, reverse=True)
    return paths

def demandcount():
    return results_dic,Demand_Assignment_Number-1,cost_all,actual_bandwidth,demands_not_satisfied


def calculations_number_of_transponder(cost,slots_list,bandwidth):
    global cost_all,results_dic,actual_bandwidth
    demandids = ['600-64QAM', '500-64QAM', '400-64QAM', '500-32QAM', '400-16QAM', '250-16QAM', '200-16QAM', '300-8QAM', '150-8QAM', '200-QPSK', '100-QPSK']
    _, _, l = slot_data_modulation()
    cost_all.append(cost)
    actual_bandwidth.append(bandwidth)
    results_dic1 = {}
    for i, j in enumerate(l):
        results_dic1[j] = slots_list[i]
    results_dic2 = results_dic
    results_dic = dict(Counter(results_dic1) + Counter(results_dic2))
    keys=list(results_dic.keys())
    for item in demandids:
        if item not in keys:
            results_dic[item] = 0


def allocate_to_path(source, destination, demand, link_matrix_free, link_matrix_allocated):
    paths = findAlternativePaths(source, destination)
    global demands_not_satisfied
    for i in paths:
        shortest_path = i['path']
        hops=int(i["hops"])
        # print(demand,source,destination,hops)
        l1 = [copy.deepcopy(link_matrix_free[j[0] - 1][j[1] - 1]) for j in shortest_path]
        intersection_link = LinkIntersection(l1)
        index = demand_OSNR(i["osnr"])
        # print(i["osnr"],hops)
        # if index != None:
        slots, slots_list, diff, actual_bandwidth, demandceiled, demand_overalldata, cost = calculate_slot(
                demand, index, i["osnr"], hops)
        allocate, got_slots = findFirstFit(intersection_link, slots)
        if (not got_slots):
            demands_not_satisfied.append([source,destination,demand])
            continue
        else:
            calculations_number_of_transponder(cost,slots_list,actual_bandwidth)
            assign_unique_ids(shortest_path)
            allocate_to_link(shortest_path, link_matrix_free, link_matrix_allocated, allocate, slots_list, diff,
                             actual_bandwidth, demand, demandceiled,demand_overalldata)
            global Demand_Assignment_Number
            demandcount()
            Demand_Assignment_Number = Demand_Assignment_Number + 1
            # print(Demand_Assignment_Number)
            printFrequenciesAndCentralFrequency(allocate, slots_list, diff)
            return shortest_path





if __name__ == '__main__':
    num_nodes = Kpathselection.setFilePath('1')
    link_matrix_free, link_matrix_allocated = initialize_matrices(num_nodes)
    allocate_to_path(9, 2, 890, link_matrix_free, link_matrix_allocated)
    allocate_to_path(3, 11, 837, link_matrix_free, link_matrix_allocated)
    allocate_to_path(6, 8, 835, link_matrix_free, link_matrix_allocated)
    # allocate_to_path(1, 9, 736, link_matrix_free, link_matrix_allocated)
    # allocate_to_path(14, 7, 5000, link_matrix_free, link_matrix_allocated)
    # allocate_to_path(14, 7, 5000, link_matrix_free, link_matrix_allocated)
    # allocate_to_path(14, 7, 5000, link_matrix_free, link_matrix_allocated)

