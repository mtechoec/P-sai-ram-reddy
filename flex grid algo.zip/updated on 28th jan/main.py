from flask import Flask, jsonify, request, send_from_directory, flash, redirect,request, session,abort, url_for,render_template
from flask_cors import CORS;import pandas as pd
import ast,os,numpy as np,collections,math
from sqlalchemy.orm import sessionmaker
from tabledef import *
engine = create_engine('sqlite:///database_.db', echo=True)
from RSAassignment import allocate_to_path,Kpathselection,initialize_matrices,findAlternativePaths,resetPathandDemandId,demandcount
from demand import slot_data_modulation
app = Flask(__name__,template_folder='templates')
CORS(app)


link_matrix_free =[];link_matrix_allocated =[];nodes_list=[];edges_list=[]
traffic_number =10;individual_traffic=5

@app.after_request
def add_header(r):

    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"         """ Add headers to both force latest IE rendering engine or Chrome Frame,and also to cache the rendered page for 10 minutes. """
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

@app.route('/', methods=['GET'])
def home():
    return render_template('dashboard.html')
    # if not session.get('logged_in'):
    #     return render_template('user.html')
    # else:
    #     return render_template('dashboard.html')

@app.route("/logout")
def logout():
    session['logged_in'] = False
    session.pop('username', None)
    return render_template('user.html')

@app.route("/login", methods=["GET", "POST"])
def do_admin_login():
    POST_USERNAME = str(request.form['username'])
    POST_PASSWORD = str(request.form['password'])
    Session = sessionmaker(bind=engine)
    s = Session()
    query = s.query(User).filter(User.username.in_([POST_USERNAME]), User.password.in_([POST_PASSWORD]))
    result = query.first()
    if result:
        session['logged_in'] = True
        flash("Logged in!")
    else:
        flash('wrong password!')
    return home()

@app.route('/user.html', methods=['GET'])
def get_user():
    return render_template('user.html')


@app.route('/dashboard.html', methods=['GET'])
def get_dashboard():
    # if not session.get('logged_in'):
    #     return get_user()
    return render_template('dashboard.html')


@app.route('/icons.html', methods=['GET'])
def get_icons():
    return render_template('icons.html')

@app.route('/edges.html', methods=['GET'])
def get_edges():
    return render_template('edges.html')\

@app.route('/nodes.html', methods=['GET'])
def get_nodes():
    return render_template('nodes.html')\

@app.route('/traffic.html', methods=['GET'])
def get_traffic():
    return render_template('traffic.html')


@app.route('/Typography.html', methods=['GET'])
def get_Typography():
    return render_template('Typography.html')

@app.route('/tables.html', methods=['GET'])
def get_tables():
    return render_template('tables.html')

@app.route('/16_AD.html', methods=['GET'])
def get_16AD():
    return render_template('16_AD.html')

@app.route('/ITUT_FLEX.html', methods=['GET'])
def get_ITUT_FLEX():
    return render_template('ITUT_FLEX.html')


def generatingdemands(filename,num_nodes):
    with open("data/" + filename + "-traffic.ini", mode="w", encoding="utf-8") as f1:
        i = 0
        f1.write("[" + "\n")
        while i < traffic_number:
            s = np.random.randint(1, num_nodes + 1)
            t = np.random.randint(1, num_nodes + 1)
            if s != t:
                for j in range(0, individual_traffic):
                    dem = np.random.randint(500,800)
                    templist = (str(s), str(t), str(dem))
                    f1.write("[" + ','.join(templist) + "]" + "," + "\n")
                i += 1
        f1.write("]")
    f1.close()


def positive_scenario(traffic_list,filename,demands_not_satisfied):
    for i in demands_not_satisfied:
        if i in traffic_list:
            traffic_list.remove(i)
    with open("data/" + filename + "-traffic.ini", mode="w", encoding="utf-8") as f1:
        f1.write("[" + "\n")
        for k in traffic_list:
            f1.write(str(k))
            f1.write(",")
            f1.write("\n")
        f1.write("]")
    f1.close()


@app.route('/getNet', methods=['POST'])
def get_Net():
    global link_matrix_free,link_matrix_allocated,nodes_list,edges_list,traffic_list   #reset global link matrices for every new getting of matrix
    link_matrix_free = [];link_matrix_allocated = [];nodes_list = [];edges_list = [];traffic_list=[];new_list=[]
    filename = str(request.get_json()['net'])
    num_nodes = Kpathselection.setFilePath(filename)
    distances = [60]
    for u in range(0, len(distances)):
        nodes_list = Kpathselection.nodes
        edges_list = Kpathselection.edges
        for j in edges_list:
            j[2] = distances[u]
        # generatingdemands(filename, num_nodes)
        with open("data/" + Kpathselection.file_name + "-traffic.ini", mode="r", encoding="utf-8") as f:
            traffic = ast.literal_eval(f.read())
        traffic_list = traffic
        resetPathandDemandId()
        link_matrix_free, link_matrix_allocated = initialize_matrices(num_nodes)
        for i in traffic:
            allocate_to_path(i[0], i[1], i[2], link_matrix_free, link_matrix_allocated)
        trafficnumber = len(traffic_list)
        for i in edges_list:
            new_list.append(i[0])
            new_list.append(i[1])
        results_nodedegree = collections.Counter(new_list).values()
        result_demandcount, demandsatisfied, cost_all, actual_bandwidth, demands_not_satisfied = demandcount()
        positive_scenario(traffic_list,filename,demands_not_satisfied)
        cost = round(sum(cost_all), 2)
        network_accoupancy_list = [(k["slot"][1] - k["slot"][0]) + 1 for i in range(num_nodes) for j in range(num_nodes) if
                                   i <= j for k in link_matrix_allocated[i][j] if
                                   k["demand_id"] in range(demandsatisfied + 1)]
        blocking_probabaility = round(((trafficnumber - demandsatisfied) / trafficnumber) * 100, 2)
        network_occupancy = round(((sum(network_accoupancy_list)) / (len(edges_list) * 384)) * 100, 2)
        bandwidth = sum(network_accoupancy_list) * 12.5
        response = {
            'nodes': Kpathselection.nodes, 'edges': Kpathselection.edges, 'freeMatrix': link_matrix_free,
            'allocMatrix': link_matrix_allocated,
            "num_nodes": num_nodes, "traffic": traffic, 'max_nodal_degree': max(results_nodedegree),
            'min_nodal_degree': min(results_nodedegree),
            'avg_nodal_degree': math.ceil(sum(results_nodedegree) / len(results_nodedegree)),
            "demand_count": result_demandcount,
            "blocking_prb": blocking_probabaility,
            "network_occupancy": network_occupancy,
        }
        print_to_excel(result_demandcount, cost, blocking_probabaility, network_occupancy, edges_list[0][2], bandwidth)


    return jsonify(response), 201


def print_to_excel(data,cost,bp,no,distance,bandwidth):
    data["Distance"]=distance
    data["spectrum"]=bandwidth
    data["cost_without regen"]=cost
    data["B.P%"]=bp
    data["Network Occupancy%"]=no
    with open("results/" + Kpathselection.file_name + "-output_results.csv", mode="a", encoding="utf-8") as f2:
        df1 = pd.DataFrame.from_records([data])
        df1.to_csv(f2)


@app.route('/nodes_edges_data', methods=['POST'])
def nodes_edges_data():
    global nodes_list,edges_list,traffic_list
    response = {
        'nodes': nodes_list,
        'edges': edges_list,
        'traffic': traffic_list,
    }
    return jsonify(response), 201

@app.route('/data_rate_slots', methods=['POST'])
def data_rate_slots():
    list_data, slot_calculation,_ = slot_data_modulation()
    response = {
        'l': list_data,
        'slots':slot_calculation,
    }
    return jsonify(response), 201

@app.route('/alternativePaths', methods=['POST'])
def alternativePaths():
    values = request.get_json()
    paths= findAlternativePaths(values['to'],values['from'])
    response = {
        'paths': paths
    }
    return jsonify(response), 201

# @app.route('/demand_divison_slots', methods=['POST'])
# def demand_divison_slots():
#
#     return jsonify(response), 201


@app.route('/assignment', methods=['POST'])
def assignment():
    global link_matrix_free,link_matrix_allocated

    values = request.get_json()
    # print(values['to']," ",values['from']," ",values['demand'])
    path= allocate_to_path(values['to'], values['from'],values['demand'], link_matrix_free, link_matrix_allocated)
    response = {
        'freeMatrix': link_matrix_free,
        'allocMatrix': link_matrix_allocated,
        'path': path
    }
    return jsonify(response), 201

if __name__ == '__main__':
    app.secret_key = os.urandom(12)
    app.run(host='localhost', port=5100)
    # app.run(host='localhost', port=5100)
