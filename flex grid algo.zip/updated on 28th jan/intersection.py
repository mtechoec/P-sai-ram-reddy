def Intersection(l1, l2, temp):
    x = max(l1[0], l2[0])
    y = min(l1[1], l2[1])
    if(x <= y):
        temp.append([x, y])

def IntersectionSets(l1, l2):
    temp = []
    i = 0
    j = 0
    while(i < len(l1) and j < len(l2)):
        # if intersection exits add it to temp
        Intersection(l1[i], l2[j], temp)
        if(l1[i][0] <= l2[j][0]):
            if(l1[i][1] <= l2[j][1]):
                i = i+1
            else:
                l1[i][0] = l2[j][1]+1

        else:
            if(l2[j][1] <= l1[i][1]):
                j = j+1
            else:
                l2[j][0] = l1[i][1]+1
    return temp

def LinkIntersection(l):
    temp = l.pop(0)  # pop the first element
    for link in l:
        temp = IntersectionSets(temp, link)
    return temp
