import math
D=[] #always reinitializing
mat=[]#always reinitializing
osnr=[]
start_frequency_slice = 196.125
cost_of_fiber = 38400
cost_one_slot = 1 #38400/384
osnr_penality=2
# OSNR MARGIN = CALCULATED OSNR - REQUIRED MARGIN #TODO to add 2dB penalty to the required OSNR
modulation_data1 =[{'id' : '600-64QAM',  'data':[{'format': '64QAM',  'OSNR': 24 + osnr_penality,'bandwidth': 87.5,'data_rate': 600,'baud_rate': 69.16,'cost_calculation':    4}]},
                    {'id': '500-64QAM', 'data': [{'format': '64QAM',  'OSNR': 24 + osnr_penality,'bandwidth': 74.9, 'data_rate': 500, 'baud_rate': 57.63,'cost_calculation': 3.5}]},
                    {'id': '400-64QAM', 'data': [{'format': '64QAM',  'OSNR': 24 + osnr_penality,'bandwidth': 59.9, 'data_rate': 400, 'baud_rate': 46.11,'cost_calculation': 2.8}]},
                    {'id': '500-32QAM', 'data': [{'format': '32QAM',  'OSNR': 21 + osnr_penality,'bandwidth': 86.5, 'data_rate': 500, 'baud_rate': 69.19,'cost_calculation': 3.2}]},
                    {'id': '400-16QAM', 'data': [{'format': '16QAM',  'OSNR': 18 + osnr_penality,'bandwidth': 82.3, 'data_rate': 400, 'baud_rate': 69.16,'cost_calculation': 2.5}]},
                    {'id': '250-16QAM', 'data': [{'format': '16QAM',  'OSNR': 18 + osnr_penality,'bandwidth': 51.5, 'data_rate': 250,'baud_rate': 43.225,'cost_calculation': 1.7}]},
                    {'id': '200-16QAM', 'data': [{'format': '16QAM',  'OSNR': 18 + osnr_penality,'bandwidth': 41.14,'data_rate': 200,'baud_rate': 34.58, 'cost_calculation': 1.5}]},
                    {'id': '300-8QAM',  'data': [{'format': '8QAM',   'OSNR': 15 + osnr_penality, 'bandwidth': 79.5, 'data_rate': 300,  'baud_rate': 69.16,'cost_calculation': 2.2}]},
                    {'id': '150-8QAM',  'data': [{'format': '8QAM',   'OSNR': 15 + osnr_penality, 'bandwidth': 39.8, 'data_rate': 150,  'baud_rate': 34.58,'cost_calculation': 1.2}]},
                    {'id': '200-QPSK',  'data': [{'format': 'QPSK',   'OSNR': 12 + osnr_penality, 'bandwidth': 75.4, 'data_rate': 200,  'baud_rate': 69.16,'cost_calculation': 1.3}]},
                    {'id': '100-QPSK',  'data': [{'format': 'QPSK',   'OSNR': 12 + osnr_penality, 'bandwidth': 37.5, 'data_rate': 100,  'baud_rate': 34.58,'cost_calculation': 1}]}
                   ]
l=[];slot_calculation=[];bit_rate_osnr=[];mod_format=[];cost_calculation=[];demand_ids_calculation=[]

for i in modulation_data1:
    l.append(i["data"][0]["data_rate"])
    slot_calculation.append(i["data"][0]["bandwidth"])
    bit_rate_osnr.append(i["data"][0]["OSNR"])
    mod_format.append(i["data"][0]['format'])
    cost_calculation.append(i["data"][0]["cost_calculation"])
    demand_ids_calculation.append(i["id"])
# print(demand_ids_calculation)

def slot_data_modulation():
    return l,slot_calculation,demand_ids_calculation

def Dash(num,j= 0):
    if(j== len(l)-1):
        k= D.copy()
        if(num/l[j]==num//l[j]):
            k.append(num // l[j])
            mat.append(k)
        return
    for i in range(0, num // l[j] + 1):
        D.append(i)
        Dash(num - i * l[j], j + 1)
        D.pop()  # pop the last element

def dB_LI(x):
    return round(10**(x/10),3)

def osnr_demand(i):
    for j in range(0,len(i)):
        if i[j] > 0:
            k = bit_rate_osnr[j]
            return k
            break


def osnrmargin_cal(osnr):
    margin_osnr=[round((osnr-i),2) for i in bit_rate_osnr]
    return margin_osnr

def sorting(demand,index,margin_osnr,hops):
    D.clear()
    if index == None:
        index = 10
    for i in range(0,index):
        D.append(0)
    mat.clear()
    demand = math.ceil(demand / 100) * 100
    Dash(demand,index)
    bandwidth = 0;data = [];cost = 0;cost_overall = 0
    for i in range(len(mat)):
        for j in range(len(mat[i])):
            cost += (2*mat[i][j]) * cost_calculation[j] # 2 *( each transponder * its corresponding cost)
            bandwidth += mat[i][j] * slot_calculation[j]
        cost_of_slots =((math.ceil(bandwidth/12.5)*12.5)/12.5)*cost_one_slot
        cost_transponders = cost
        cost_overall = (cost_of_slots)*hops + cost_transponders
        osnr = osnr_demand(mat[i])
        data.append(
            {"cost":cost_overall,"spectrum": bandwidth,"matrix": mat[i],
             "cost_transponders":cost_transponders,"cost_slots":cost_of_slots})
        cost = 0
        bandwidth = 0
    data.sort(key=SortBycost)
    # print(data[0])
    return data,demand

def SortBycost(val):
    return val['cost']

def calculate_slot(demand,index,osnr,hops):
    margin_osnr = osnrmargin_cal(osnr)
    demand_data,demand_ceiled = sorting(demand,index,margin_osnr,hops)
    bandwidth_overall = [];slots_list = [];cost=[]
    for i in demand_data:
        bandwidth_overall.append(i["spectrum"])
        slots_list.append(i["matrix"])
        cost.append(i["cost"])
    bandwidth=(math.ceil(bandwidth_overall[0]/12.5)*12.5)
    overall_slots= int(bandwidth/12.5)
    diff= ((math.ceil(bandwidth_overall[0]/12.5)*12.5)-bandwidth_overall[0])/(2*1e3)#difference of frequiences from orizin to be printed,its already in THZ
    # print("Slots==> ",round_of_slots," diff:",diff)
    return overall_slots,slots_list[0],diff,bandwidth,demand_ceiled,demand_data,cost[0] #here mat[index] is actual slot list like [0,0,0,100]

#the below logic is not used in server and the code is written on client dashboard.html ..please change code and values there
def printCentralFrequency(start,end):
    num= round((start - end)/0.001)
    centralfreq = round(start - (num / 2) * 0.001, 3)
    centralfreq = wavelength_calc(centralfreq)
    # print("Central frequency 1",centralfreq,wavelength_calc(end))

def wavelength_calc(x):
    return round(((2.9979245e8 / x) / 1e3), 3)


def printFrequenciesAndCentralFrequency(allocate,slots_list,diff):
    start_frequency = start_frequency_slice-(allocate[0]-1)*0.0125-diff #diff is already in thz
    for i in range(len(slots_list)):
        for j in range(slots_list[i]):
            printCentralFrequency(start_frequency,round(start_frequency-slot_calculation[i]/1e3,3))
            start_frequency= round(start_frequency-slot_calculation[i]/1e3,3)
    start_frequency = wavelength_calc(start_frequency)
    # print("start frequency 1 ", start_frequency)
    return

